# CloudNative / BMT 

BMT program consists of various tools to test Cloud Native DBMSs

1) Insert/Delete/Update a number of records with many fields to a table 
2) Select a number of records from a table
3) With various options, you can test the performance of Cloud Native DBMSs

Directory structure

1) Test4Single: BMT for a single node of Altibase
2) Test4Replication: BMT for 1 Read/Many  and many Read Architecture
3) Test4DMES: BMT for Big memory virtualizaion technology 
4) Test4Sharding: BMT for Sharding 




