set linesize 1024; 												                                                                        
set colsize 90; 														                                                                        
set feedback off; 													                                                                        
set heading off ;                                                                                                  
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_SYSSTAT_LIST'
     , SEQNUM
     , NAME
     , VALUE
  FROM V$SYSSTAT
 WHERE SEQNUM < 88;
