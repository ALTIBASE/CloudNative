set linesize 1024; 												                                                         
set colsize 40; 														                                                         
set feedback off; 													                                                         
set heading off ;                                                                                   
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME
     , '_MON_SESSION_COUNT'
     , COUNT(*) AS SID_COUNT
  FROM V$SESSION;
 
