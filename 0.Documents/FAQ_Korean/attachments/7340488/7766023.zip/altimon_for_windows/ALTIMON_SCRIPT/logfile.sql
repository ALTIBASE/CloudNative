set linesize 1024; 												                                                                
set colsize 40; 														                                                              
set feedback off; 													                                                              
set heading off ; 																																										    
select to_char(sysdate, 'HH:MI:SS') time, '_MON_LOGFILE_COUNT',                                              
        (select OLDEST_LOGFILE_NO from v$log) as old_log,																						    
        (select current_logfile from v$archive) as curr_log,                                            
       ((select current_logfile from v$archive) - (select OLDEST_LOGFILE_NO from v$log)) as log_gap 
from dual;										                        																								    