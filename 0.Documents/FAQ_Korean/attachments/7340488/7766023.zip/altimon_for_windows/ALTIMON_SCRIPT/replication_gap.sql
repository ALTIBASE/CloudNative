set linesize 1024; 												                               
set colsize 40; 														                               
set feedback off; 													                               
set heading off ;                                                         
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_REP_GAP'
     , REP_NAME
     , REP_SN
     , REP_GAP
  FROM V$REPGAP
 ORDER BY REP_NAME, REP_GAP;