set linesize 1024; 																										  
set colsize 40; 																												
set feedback off; 																											
set heading off ; 																											
select to_char(sysdate, 'HH:MI:SS') time, '_MON_MEMSTAT_SUM',              
       trunc(sum(MAX_TOTAL_SIZE)/1024/1024, 2) as max_total_mb,   
       trunc(sum(ALLOC_SIZE)/1024/1024, 2) as current_mb 	        
from v$memstat;                                                         