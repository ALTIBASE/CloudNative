set linesize 1024; 												                       
set colsize 40; 														                       
set feedback off; 													                       
set heading off ;                                                 
select to_char(sysdate, 'HH:MI:SS') time, 'MEM_DATABASE_USAGE', 
   trunc(mem_alloc_page_count*32/1024, 2) as alloc_mem_mb,     
   trunc(mem_free_page_count*32/1024, 2) as free_mem_mb        
from v$database;                                                  
