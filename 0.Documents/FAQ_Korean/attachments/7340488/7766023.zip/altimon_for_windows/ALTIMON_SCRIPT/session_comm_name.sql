set linesize 1024; 												                                                                                              
set colsize 40; 														                                                                                              
set feedback off; 													                                                                                              
set heading off ;                                                                                                                        
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_SESSION_COMM_NAME'
     , COMM_NAME
     , COUNT(*)
  FROM V$SESSION
 GROUP BY COMM_NAME
 ORDER BY 4 DESC;

