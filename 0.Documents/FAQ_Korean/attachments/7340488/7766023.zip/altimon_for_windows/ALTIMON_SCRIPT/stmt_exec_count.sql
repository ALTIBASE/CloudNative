set linesize 1024; 												                   
set colsize 40; 														                   
set feedback off; 													                   
set heading off ;                                             
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_STMT_EXEC_COUNT'
     , EXECUTE_FLAG
     , COUNT(*) AS STMT_COUNT
  FROM V$STATEMENT
 GROUP BY EXECUTE_FLAG
 ORDER BY 4;
 