set linesize 1024; 												                                
set colsize 40; 														                                
set feedback off; 													                                
set heading off ;                                                          
select to_char(sysdate, 'HH:MI:SS') time, '_MON_MEM_TBL_USAGE',               
   user.user_name||'.'||table_name,                                                             
   FIXED_ALLOC_MEM+VAR_ALLOC_MEM alloc,                                    
   (FIXED_ALLOC_MEM+VAR_ALLOC_MEM)-(FIXED_USED_MEM+VAR_USED_MEM) free  
from system_.sys_tables_ a, v$memtbl_info b, system_.sys_users_ user                               
where a.table_oid = b.table_oid and a.user_id <> 1 and user.user_id = a.user_id                                          
order by table_name;                                                                
