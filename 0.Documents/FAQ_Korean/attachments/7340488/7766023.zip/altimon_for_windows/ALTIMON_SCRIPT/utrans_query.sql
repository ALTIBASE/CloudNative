set linesize 1024; 												                        
set colsize 90; 														                        
set feedback off; 													                        
set heading off ;                                                  
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_UTRANS_QUERY'
     , ST.SESSION_ID AS SID
     , SS.COMM_NAME AS IP
     , SS.CLIENT_PID AS PID
     , ST.ID AS STMT_ID
     , BASE_TIME - TR.FIRST_UPDATE_TIME AS UTRANS_TIME
  FROM V$TRANSACTION TR
     , V$STATEMENT ST
     , V$SESSION SS
     , V$SESSIONMGR
 WHERE TR.ID = ST.TX_ID
   AND ST.SESSION_ID = SS.ID
   AND TR.FIRST_UPDATE_TIME != 0
   AND (BASE_TIME - TR.FIRST_UPDATE_TIME) > 60;
              
