set linesize 1024; 												                                       
set colsize 40; 														                                       
set feedback off; 													                                       
set heading off ;                                                                 
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_LOCK_DESC'
     , B.SESSION_ID AS SID
     , B.TX_ID AS TID
     , B.IS_GRANT AS ISGRAN
     , B.LOCK_DESC AS LDESC
     , A.TABLE_NAME AS LTABLE
     , TRUNC(C.TOTAL_TIME/1000000, 4) AS TTIME
  FROM SYSTEM_.SYS_TABLES_ A
     , V$LOCK_STATEMENT B
     , V$STATEMENT C
 WHERE A.TABLE_OID = B.TABLE_OID
   AND C.SESSION_ID = B.SESSION_ID
   AND C.TX_ID = B.TX_ID
   AND (C.TOTAL_TIME/1000000) > 1
 GROUP BY B.SESSION_ID
     , B.TX_ID
     , B.IS_GRANT
     , TOTAL_TIME
     , A.TABLE_NAME
     , B.LOCK_DESC
 ORDER BY B.SESSION_ID
     , B.TX_ID
     , B.IS_GRANT
     , TOTAL_TIME
     , A.TABLE_NAME
     , B.LOCK_DESC;
