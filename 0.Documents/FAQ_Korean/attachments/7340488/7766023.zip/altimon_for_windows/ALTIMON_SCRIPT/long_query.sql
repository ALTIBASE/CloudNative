set linesize 1024; 												                                                  
set colsize 100; 														                                                
set feedback off; 													                                                  
set heading off ;                                                                            
select to_char(sysdate, 'HH:MI:SS') time, '_MON_LONG_QUERY',                                    
       start_time,                                                                           
       session_id sid,                                                                       
       comm_name ip,                                                                         
       client_pid pid,                                                                       
       stmt_id,                                                                              
       tx_id,                                                                                
       active_flag,                                                                          
       execute_flag,                                                                         
       begin_flag,                                                                           
       trunc(execute_time/1000000,2) rtime,                                               
       trunc(fetch_time/1000000,2) ftime,                                                 
       trunc(total_time/1000000,2) ttime,                                                 
       substr(query, 1, 100) qry                                                           
from ( select CASE2(LAST_QUERY_START_TIME = 0, '1970/01/01 12:00:00',                    
        TO_CHAR(TO_DATE('1970010109','YYYYMMDDHH') +                                      
        LAST_QUERY_START_TIME/60/60/24 , 'YYYY/MM/DD HH:MI:SS')) as start_time,         
              session_id,                                                                    
              id as stmt_id,                                                                 
              tx_id,                                                                         
              execute_time,                                                                  
              fetch_time,                                                                    
              total_time,                                                                    
              execute_flag,                                                                  
              begin_flag,                                                                    
              query                                                                          
       FROM v$statement) a, v$session b                                                     
where a.session_id = b.id                                                                    
  and query not like '%LAST_QUERY_START_TIME%'                                               
  and total_time/1000000 > 1                                                               
  --and (sysdate - to_date(start_time, 'YYYY/MM/DD HH:MI:SS'))*24*60*60 >= total_time 
  and IDLE_START_TIME = 0                                                                    
  and CURRENT_STMT_ID = stmt_id                                                              
order by ttime desc;                                                                         
