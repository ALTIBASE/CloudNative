set linesize 1024; 												          
set colsize 40; 														          
set feedback off; 													          
set heading off ;                                    
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_MEM_GC'
     , GC_NAME
     --, MINMEMSCNINTXS-SCNOFTAIL
     , ADD_OID_CNT-GC_OID_CNT GC_GAP
  FROM V$MEMGC;
 