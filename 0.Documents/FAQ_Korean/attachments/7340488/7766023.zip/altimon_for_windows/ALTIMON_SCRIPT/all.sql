set linesize 1024; 												                                                                
set colsize 40; 														                                                              
set feedback off; 													                                                              
set heading off ; 

--LOGFILE COUNT																																								    
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_LOGFILE_COUNT'
     , (SELECT OLDEST_LOGFILE_NO FROM V$LOG) AS OLD_LOG
     , (SELECT CURRENT_LOGFILE FROM V$ARCHIVE) AS CURR_LOG
     , ((SELECT CURRENT_LOGFILE FROM V$ARCHIVE) - (SELECT OLDEST_LOGFILE_NO FROM V$LOG)) AS LOG_GAP
  FROM DUAL;


--MEMSTAT_SUM
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_MEMSTAT_SUM'
     , TRUNC(SUM(MAX_TOTAL_SIZE)/1024/1024, 2) AS MAX_TOTAL_MB
     , TRUNC(SUM(ALLOC_SIZE)/1024/1024, 2) AS CURRENT_MB
  FROM V$MEMSTAT;
                                                                                  
                                                     
-- MEMSTAT LIMIT
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_MEMSTAT_LIST'
     , NAME
     , MAX_TOTAL_SIZE
     , ALLOC_SIZE
  FROM V$MEMSTAT
 ORDER BY ALLOC_SIZE DESC LIMIT 30;


--MEM_DATABASE_USAGE
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_MEM_DATABASE_USAGE'
     , TRUNC(MEM_ALLOC_PAGE_COUNT*32/1024, 2) AS ALLOC_MEM_MB
     , TRUNC(MEM_FREE_PAGE_COUNT*32/1024, 2) AS FREE_MEM_MB
  FROM V$DATABASE;
 



--TABLESPACE USAGE
SELECT to_char(sysdate, 'HH:MI:SS') time, '_MON_TBS_USAGE'
     , '-' tbs_name
     , to_char(mem_max_db_size/1024/1024) 'MAX(M)'
     , round(mem_alloc_page_count*32/1024, 2) 'TOTAL(M)'
     , trunc((mem_alloc_page_count-mem_free_page_count)*32/1024, 2) 'ALLOC(M)'
     , to_char((SELECT round(sum((fixed_used_mem + var_used_mem))/(1024*1024), 3)
                  FROM v$memtbl_info)) 'USED(M)'
     , trunc(((mem_alloc_page_count-mem_free_page_count)*32*1024)/mem_max_db_size, 4)*100 'USAGE(%)'
     , '' state
     , '' 'AUTOEXTEND'
  FROM v$database                                                                                                                                                                                                         
 UNION ALL                                                                                                                                                                                                                      
SELECT to_char(sysdate, 'HH:MI:SS') time, '_MON_TBS_USAGE'
     , name tbs_name
     , decode(maxsize, 140737488322560, 'UNDEFINED', maxsize) 'MAX(M)'
     , ROUND(allocated_page_count * page_size / 1024 / 1024, 2) 'TOTAL(M)'
     , ROUND(nvl(m.alloc_page_count-m.free_page_count, total_page_count)*page_size/1024/1024, 2) 'ALLOC(M)'
     , to_char(mt.used) 'USED(M)'
     , decode(maxsize, 140737488322560, ROUND((m.alloc_page_count-m.free_page_count)*page_size/ mem_max_db_size*100, 2), ROUND((m.alloc_page_count-m.free_page_count)*page_size/maxsize*100, 2)) 'USAGE(%)'
     , decode(state, 1, 'OFFLINE', 2, 'ONLINE', 5, 'OFFLINE BACKUP', 6, 'ONLINE BACKUP', 128, 'DROPPED', 'DISCARDED') state
     , decode(autoextend_mode, 1, 'ON', 'OFF') 'AUTOEXTEND'
  FROM v$database d
     , v$tablespaces t
     , v$mem_tablespaces m
     , (SELECT tablespace_id
             , round(sum((fixed_used_mem + var_used_mem))/(1024*1024), 3) used
          FROM v$memtbl_info
         GROUP BY tablespace_id) mt
 WHERE t.id = m.space_id
   AND id = mt.tablespace_id                                                                                                                                                                                                  
 UNION ALL                                                                                                                                                                                                                      
SELECT to_char(sysdate, 'HH:MI:SS') time, '_MON_TBS_USAGE'
     , name tbs_name
     , to_char(ROUND(d.max * page_size / 1024 /1024, 2)) 'MAX(M)'
     , ROUND(total_page_count * page_size / 1024 / 1024, 2) 'TOTAL(M)'
     , decode(type, 7, ROUND((SELECT (sum(total_extent_count*page_count_in_extent) * page_size)/1024/1024
                          FROM v$udsegs)+(SELECT (sum(total_extent_count*page_count_in_extent) * page_size)/1024/1024
                          FROM v$tssegs), 2), ROUND(allocated_page_count * page_size / 1024 / 1024, 2)) 'ALLOC(M)'
     , '-' 'USED(M)'
     , decode(type, 7, ROUND(((SELECT sum(total_extent_count*page_count_in_extent)
                                  FROM v$udsegs)+(SELECT sum(total_extent_count*page_count_in_extent)
                                  FROM v$tssegs)) / d.max* 100, 2), ROUND(allocated_page_count / d.max * 100, 2)) 'USAGE(%)'
     , decode(state, 1, 'OFFLINE', 2, 'ONLINE', 5, 'OFFLINE BACKUP', 6, 'ONLINE BACKUP', 128, 'DROPPED', 'DISCARDED') state
     , d.autoextend
  FROM v$tablespaces t
     , (SELECT spaceid
             , sum(decode(maxsize, 0, currsize, maxsize)) AS max
             , decode(max(autoextend), 1, 'ON', 'OFF') 'AUTOEXTEND'
          FROM v$datafiles
         GROUP BY spaceid) d
 WHERE t.id = d.spaceid
   AND t.type NOT IN (3, 4)                                                                                                                                                                        
union all                                                                                                                                                                                                                       
SELECT to_char(sysdate, 'HH:MI:SS') time, '_MON_TBS_USAGE'
     , name tbs_name
     , to_char(ROUND(d.max * page_size / 1024 /1024, 2)) 'MAX(M)'
     , ROUND(total_page_count * page_size / 1024 / 1024, 2) 'TOTAL(M)'
     , ROUND(allocated_page_count * page_size / 1024 / 1024, 2) 'ALLOC(M)'
     , to_char(round(ds.used/1024/1024, 2)) 'USED(M)'
     , round((ds.used)/(d.max*page_size)* 100, 2) 'USAGE(%)'
     , decode(state, 1, 'OFFLINE', 2, 'ONLINE', 5, 'OFFLINE BACKUP', 6, 'ONLINE BACKUP', 128, 'DROPPED', 'DISCARDED') state
     , d.autoextend
  FROM v$tablespaces t
     , (SELECT spaceid
             , sum(decode(maxsize, 0, currsize, maxsize)) AS max
             , decode(max(autoextend), 1, 'ON', 'OFF') 'AUTOEXTEND'
          FROM v$datafiles
         GROUP BY spaceid) d
     , (SELECT space_id
             , sum(TOTAL_USED_SIZE) used
          FROM x$segment
         GROUP BY space_id) ds
 WHERE t.id = d.spaceid
   AND ds.space_id = t.id;
                                                                                                                                                                                                     
--TABLESPACE USAGE END



--DISK_TBL_USAGE
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_DISK_TBL_USAGE'
     , ROUND(SUM(DISK_TOTAL_PAGE_CNT)*8/1024) AS 'USED(M)'
  FROM V$DISKTBL_INFO A
     , V$TABLESPACES B
 WHERE A.TABLESPACE_ID=B.ID
 GROUP BY NAME
 ORDER BY NAME;
                                                       



--MEM_TBL_USAGE
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_MEM_TBL_USAGE'
     , USER.USER_NAME||'.'||TABLE_NAME
     , FIXED_ALLOC_MEM+VAR_ALLOC_MEM ALLOC
     , (FIXED_ALLOC_MEM+VAR_ALLOC_MEM)-(FIXED_USED_MEM+VAR_USED_MEM) FREE
  FROM SYSTEM_.SYS_TABLES_ A
     , V$MEMTBL_INFO B
     , SYSTEM_.SYS_USERS_ USER
 WHERE A.TABLE_OID = B.TABLE_OID
   AND A.USER_ID <> 1
   AND USER.USER_ID = A.USER_ID
 ORDER BY TABLE_NAME;
 
 
 
 

--SERVICE_THREAD
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_SERVICE_THREAD'
     , 'TYPE__'||TYPE
     , COUNT(*) CNT
  FROM V$SERVICE_THREAD
 GROUP BY TYPE 
union all
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_SERVICE_THREAD'
     , 'STATE_'||STATE
     , COUNT(*) CNT
  FROM V$SERVICE_THREAD
 GROUP BY STATE
ORDER BY 3;

 
 
 
 
 
 --SESSION_COUNT
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_SESSION_COUNT'
     , COUNT(*) AS SID_COUNT
  FROM V$SESSION;
 



--SESSION_COMM_NAME
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_SESSION_COMM_NAME'
     , COMM_NAME
     , COUNT(*)
  FROM V$SESSION
 GROUP BY COMM_NAME
 ORDER BY 4 DESC;





--STATEMENT_COUNT
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_STMT_COUNT'
     , COUNT(*) AS STMT_COUNT
  FROM V$STATEMENT;
  
  
  
  
--STATEMENT_EXEC_COUNT
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_STMT_EXEC_COUNT'
     , EXECUTE_FLAG
     , COUNT(*) AS STMT_COUNT
  FROM V$STATEMENT
 GROUP BY EXECUTE_FLAG
 ORDER BY 4;
 



--MEM_GC
set linesize 1024; 												          
set colsize 40; 														          
set feedback off; 													          
set heading off ;                                    
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_MEM_GC'
     , GC_NAME
     --, MINMEMSCNINTXS-SCNOFTAIL
     , ADD_OID_CNT-GC_OID_CNT GC_GAP
  FROM V$MEMGC;
 
 
 

--LOCK_DESC
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_LOCK_DESC'
     , B.SESSION_ID AS SID
     , B.TX_ID AS TID
     , B.IS_GRANT AS ISGRAN
     , B.LOCK_DESC AS LDESC
     , A.TABLE_NAME AS LTABLE
     , TRUNC(C.TOTAL_TIME/1000000, 4) AS TTIME
  FROM SYSTEM_.SYS_TABLES_ A
     , V$LOCK_STATEMENT B
     , V$STATEMENT C
 WHERE A.TABLE_OID = B.TABLE_OID
   AND C.SESSION_ID = B.SESSION_ID
   AND C.TX_ID = B.TX_ID
   AND (C.TOTAL_TIME/1000000) > 1
 GROUP BY B.SESSION_ID
     , B.TX_ID
     , B.IS_GRANT
     , TOTAL_TIME
     , A.TABLE_NAME
     , B.LOCK_DESC
 ORDER BY B.SESSION_ID
     , B.TX_ID
     , B.IS_GRANT
     , TOTAL_TIME
     , A.TABLE_NAME
     , B.LOCK_DESC;
     
     
     

--LOCK_TX_DETAIL
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_LOCK_TX_DETAIL'
     , TX.ID TX_ID
     , WAIT_FOR_TRANS_ID BLOCKED_TX_ID
     , DECODE(TX.STATUS, 0, 'BEGIN', 1, 'PRECOMMIT', 2, 'COMMIT_IN_MEMORY', 3, 'COMMIT', 4, 'ABORT', 5, 'BLOCKED', 6, 'END') STATUS
     , DECODE(TX.LOG_TYPE, 0, U1.USER_NAME, 'REPLICATION') USER_NAME
     , DECODE(TX.LOG_TYPE, 0, TX.SESSION_ID, RT.REP_NAME) SESSION_ID
     , DECODE(TX.LOG_TYPE, 0, ST.COMM_NAME, RR.PEER_IP) CLIENT_IP
     , DECODE(ST.AUTOCOMMIT_FLAG, 1, 'ON', 'OFF') AUTOCOMMIT
     , L.LOCK_DESC
     , DECODE(TX.FIRST_UPDATE_TIME, 0, '0', TO_CHAR(TO_DATE('1970010109', 'YYYYMMDDHH') + TX.FIRST_UPDATE_TIME / (60*60*24), 'MM/DD HH:MI:SS')) FIRST_UPDATE_TIME
     , U2.USER_NAME||'.'||T.TABLE_NAME TABLE_NAME
     , DECODE(TX.LOG_TYPE, 0, SUBSTR(ST.QUERY, 1, 40), 'REMOTE TX_ID '||REMOTE_TID) CURRENT_QUERY
     , DECODE(TX.DDL_FLAG, 0, 'NON-DDL', 'DDL') DDL
     , DECODE(TX.FIRST_UNDO_NEXT_LSN_FILENO, -1, '-', TX.FIRST_UNDO_NEXT_LSN_FILENO) 'LOGFILE#'
  FROM V$TRANSACTION TX
     , V$LOCK L LEFT OUTER JOIN (SELECT ST.*, SS.AUTOCOMMIT_FLAG, SS.DB_USERID, SS.COMM_NAME
          FROM V$STATEMENT ST, V$SESSION SS
         WHERE SS.ID = ST.SESSION_ID
           AND SS.CURRENT_STMT_ID = ST.ID) ST ON L.TRANS_ID = ST.TX_ID LEFT OUTER JOIN V$REPRECEIVER_TRANSTBL RT ON L.TRANS_ID = RT.LOCAL_TID LEFT OUTER JOIN V$REPRECEIVER RR ON RT.REP_NAME = RR.REP_NAME LEFT OUTER JOIN V$LOCK_WAIT LW ON L.TRANS_ID = LW.TRANS_ID LEFT OUTER JOIN SYSTEM_.SYS_USERS_ U1 ON ST.DB_USERID = U1.USER_ID
     , SYSTEM_.SYS_TABLES_ T LEFT OUTER JOIN SYSTEM_.SYS_USERS_ U2 ON T.USER_ID = U2.USER_ID
 WHERE TX.ID = L.TRANS_ID
   AND T.TABLE_OID = L.TABLE_OID
   AND TX.STATUS != 6 ;
   
   

--LONG_RUN_QUERY
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_LONG_QUERY'
     , START_TIME
     , SESSION_ID SID
     , COMM_NAME IP
     , CLIENT_PID PID
     , STMT_ID
     , TX_ID
     , ACTIVE_FLAG
     , EXECUTE_FLAG
     , BEGIN_FLAG
     , TRUNC(EXECUTE_TIME/1000000,2) RTIME
     , TRUNC(FETCH_TIME/1000000,2) FTIME
     , TRUNC(TOTAL_TIME/1000000,2) TTIME
     , SUBSTR(QUERY, 1, 100) QRY
  FROM (SELECT CASE2(LAST_QUERY_START_TIME = 0, '1970/01/01 12:00:00', TO_CHAR(TO_DATE('1970010109','YYYYMMDDHH') + LAST_QUERY_START_TIME/60/60/24 , 'YYYY/MM/DD HH:MI:SS')) AS START_TIME
             , SESSION_ID
             , ID AS STMT_ID
             , TX_ID
             , EXECUTE_TIME
             , FETCH_TIME
             , TOTAL_TIME
             , EXECUTE_FLAG
             , BEGIN_FLAG
             , QUERY
          FROM V$STATEMENT) A
     , V$SESSION B
 WHERE A.SESSION_ID = B.ID
   AND QUERY NOT LIKE '%LAST_QUERY_START_TIME%'
   AND TOTAL_TIME/1000000 > 1
   --AND (SYSDATE - TO_DATE(START_TIME, 'YYYY/MM/DD HH:MI:SS'))*24*60*60 >= TOTAL_TIME 
   AND IDLE_START_TIME = 0
   AND CURRENT_STMT_ID = STMT_ID
 ORDER BY TTIME DESC;
 


--UTRANS_QUERY
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_UTRANS_QUERY'
     , ST.SESSION_ID AS SID
     , SS.COMM_NAME AS IP
     , SS.CLIENT_PID AS PID
     , ST.ID AS STMT_ID
     , BASE_TIME - TR.FIRST_UPDATE_TIME AS UTRANS_TIME
  FROM V$TRANSACTION TR
     , V$STATEMENT ST
     , V$SESSION SS
     , V$SESSIONMGR
 WHERE TR.ID = ST.TX_ID
   AND ST.SESSION_ID = SS.ID
   AND TR.FIRST_UPDATE_TIME != 0
   AND (BASE_TIME - TR.FIRST_UPDATE_TIME) > 60;
              
              

--REPLICATION_GAP
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_REP_GAP'
     , REP_NAME
     , REP_SN
     , REP_GAP
  FROM V$REPGAP
 ORDER BY REP_NAME, REP_GAP;




--UNDO_USAGE
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_UNDO_USAGE'
     , TOTAL_EXT_CNT TOTAL
     , TX_EXT_CNT TX_CNT
     , USED_EXT_CNT USED
     , UNSTEALABLE_EXT_CNT UNSTEAL
     , REUSABLE_EXT_CNT REUSE
  FROM V$DISK_UNDO_USAGE;
 


--SYSSTAT_LIST
set colsize 90; 														                                                                                                                                                                      
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_SYSSTAT_LIST'
     , SEQNUM
     , NAME
     , VALUE
  FROM V$SYSSTAT
 WHERE SEQNUM < 88;
 
