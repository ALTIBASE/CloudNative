set linesize 1024; 												                       
set colsize 40; 														                       
set feedback off; 													                       
set heading off ;                                                 
select to_char(sysdate, 'HH:MI:SS') time, '_MON_DISK_TBL_USAGE',     
       round(sum(DISK_TOTAL_PAGE_CNT)*8/1024) AS 'USED(M)' 
from v$disktbl_info a, v$tablespaces b                            
where a.TABLESPACE_ID=b.id group by name                          
order by name;                                                    
