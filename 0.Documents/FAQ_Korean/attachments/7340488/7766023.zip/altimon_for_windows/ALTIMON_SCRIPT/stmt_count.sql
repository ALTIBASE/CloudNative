set linesize 1024; 												                                                         
set colsize 40; 														                                                         
set feedback off; 													                                                         
set heading off ;                                                                                   
select to_char(sysdate, 'HH:MI:SS') time, '_MON_STMT_COUNT', count(*) as stmt_count from v$statement;
