set linesize 1024; 												                    
set colsize 40; 														                    
set feedback off; 													                    
set heading off ; 													                    
select to_char(sysdate, 'HH:MI:SS') time, '_MON_MEMSTAT_LIST',    
       name,																                    
       MAX_TOTAL_SIZE,  										                    
       ALLOC_SIZE       										                    
from v$memstat order by alloc_size desc limit 30;              
