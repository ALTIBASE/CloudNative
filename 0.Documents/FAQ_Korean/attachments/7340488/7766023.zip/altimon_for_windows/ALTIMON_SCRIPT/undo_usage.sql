set linesize 1024; 												                     
set colsize 40; 														                     
set feedback off; 		                                           
set heading off ;											                         
SELECT TO_CHAR(SYSDATE, 'HH:MI:SS') TIME, '_MON_UNDO_USAGE'
     , TOTAL_EXT_CNT TOTAL
     , TX_EXT_CNT TX_CNT
     , USED_EXT_CNT USED
     , UNSTEALABLE_EXT_CNT UNSTEAL
     , REUSABLE_EXT_CNT REUSE
  FROM V$DISK_UNDO_USAGE;
                                     
