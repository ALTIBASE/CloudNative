set linesize 1000
select * from v$log;
select * from v$archive;
select * from v$repgap;
select * from v$repsender;
select * from v$repreceiver;
select * from system_.sys_replications_;
