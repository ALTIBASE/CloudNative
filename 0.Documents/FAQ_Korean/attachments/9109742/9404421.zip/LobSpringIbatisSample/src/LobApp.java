import java.io.IOException;
import java.io.Reader;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.altibase.lob.LobSample;
import com.altibase.lob.LobSampleDao;
import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

public class LobApp {

	
	public static void main(String[] args) throws IOException, SQLException, InterruptedException {
		
		Resource resource = new ClassPathResource("applicationContext.xml");
		BeanFactory factory = new XmlBeanFactory(resource);
		LobSampleDao lobSampleDao = (LobSampleDao)factory.getBean("lobSampleDao");

		//insert LobSample
		StringBuffer msg=new StringBuffer("Spring is a modular Java/J2EE application framework, based on code published in Expert One-on-OneJ2EE Design and Developmentby Rod Johnson (Wrox, 2002). Spring includes:");
        for(int i=0; i<10;i++){
        	msg.append(msg.toString());		
        }
       
        LobSample lob1 = new LobSample(1,msg.toString());
        LobSample lob2 = new LobSample(2,msg.toString());
        LobSample lob3 = new LobSample(3,msg.toString());
        lobSampleDao.insertLobSample (lob1);
        lobSampleDao.insertLobSample (lob2);
        lobSampleDao.insertLobSample ( lob3);
		System.out.println();
		System.out.println("inserted lob");
		
		//getAllLobSamples
        
		List<LobSample> list = lobSampleDao.getAllLobSamples();
		
		System.out.println("Selected "+list.size()+" records.");
		for(int i=0; i< list.size();i++){
			System.out.println(list.get(i));
		}
		
        
		//update LobSample
		lob1.setLobcolumn("Update lob message.....");
		lobSampleDao.updateLobSample(lob1);
		System.out.println();
		System.out.println("updated lob");
		
		//getLobSample
		/*
		LobSample lobSample1 = lobSampleDao.getLobSample(1);
		System.out.println(lobSample1);
		*/
		//delete LobSample
		lobSampleDao.deleteLobSample(1);	
		System.out.println();
		System.out.println("deleted lob");
		
		//getAllLobSamples
		list = lobSampleDao.getAllLobSamples();
		System.out.println("Selected "+list.size()+" records.");
		for(int i=0; i< list.size();i++){
			System.out.println(list.get(i));
		}
		
		
		

	}

}
