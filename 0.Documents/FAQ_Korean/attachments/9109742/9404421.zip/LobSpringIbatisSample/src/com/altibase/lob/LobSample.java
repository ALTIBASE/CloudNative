package com.altibase.lob;


public class LobSample {
	private int lob_id;
	private String lobcolumn;
    public LobSample(){}
    public LobSample(int lob_id,String lobcolumn){
    	this.lob_id = lob_id;
    	this.lobcolumn = lobcolumn;
    }
	public void setLobcolumn(String lobcolumn) {
		this.lobcolumn = lobcolumn;
	}

	public String getLobcolumn() {
		return lobcolumn;
	}
	public void setLob_id(int lob_id) {
		this.lob_id = lob_id;
	}
	public int getLob_id() {
		return lob_id;
	} 
	public String toString(){
		return "Lob_id="+lob_id+", Message="+lobcolumn;
	
	}
}
