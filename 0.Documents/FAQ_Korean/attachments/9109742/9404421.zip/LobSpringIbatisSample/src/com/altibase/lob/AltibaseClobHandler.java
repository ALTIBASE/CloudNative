package com.altibase.lob;

import java.io.Reader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.sql.Clob;
import java.sql.SQLException;

import com.ibatis.sqlmap.client.extensions.ParameterSetter;
import com.ibatis.sqlmap.client.extensions.ResultGetter;
import com.ibatis.sqlmap.client.extensions.TypeHandlerCallback;

public class AltibaseClobHandler implements TypeHandlerCallback{

	
    public Object getResult(ResultGetter getter) throws SQLException {   
        /*
        if(getter.wasNull()){
        	return null;
        }else{
	        Clob clob = getter.getClob();
	        String str = getClobToString(clob);
	        return str;
        }
        */
    	return getter.getClob().toString();
    }   
    public void setParameter(ParameterSetter setter, Object parameter) throws SQLException {   
        String str = (String) parameter;   
        if(str != null){
	        StringReader sr = new StringReader(str);
            setter.setCharacterStream(sr, str.length());
        }else{
        	setter.setString(null);
        }
            
    }   
    public Object valueOf(String s) {   
        return s;   
    }
    private String getClobToString(Clob clob) throws SQLException{
    	int readSize = 0;
    	char[] buff = new char[1024];
    	Reader reader = clob.getCharacterStream();
    	StringBuffer sb = new StringBuffer();
    	try{
    			while((readSize = reader.read(buff))> 0){
    				sb.append(buff,0,readSize);
    				
    			}
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return sb.toString();
    	
    	
    }
}  

