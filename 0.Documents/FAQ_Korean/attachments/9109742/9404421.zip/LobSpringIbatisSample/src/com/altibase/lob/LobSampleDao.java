package com.altibase.lob;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

public class LobSampleDao {
	private SqlMapClient sqlMapClient;
	public LobSampleDao(){}
	
	public void setSqlMapClient(SqlMapClient sqlMapClient) {
		this.sqlMapClient = sqlMapClient;
	}

	public SqlMapClient getSqlMapClient() {
		return sqlMapClient;
	}
	public void insertLobSample(LobSample l) throws SQLException{
		sqlMapClient.insert ("insertLobSample", l);
	}
	
	public void updateLobSample(LobSample l) throws SQLException{
		sqlMapClient.insert ("updateLobSample", l);
	}
	public void deleteLobSample(int lob_id) throws SQLException{
		sqlMapClient.delete ("deleteLobSample", new Integer(lob_id));
	}
	public LobSample getLobSample(int lob_id) throws SQLException{
		LobSample lob = (LobSample) sqlMapClient.queryForObject ("getLobSample", new Integer(lob_id));
		return lob;
	}
	public List<LobSample> getAllLobSamples() throws SQLException{
		List<LobSample> list = sqlMapClient.queryForList("getAllLobSamples");
		return list;
	}
	
}
