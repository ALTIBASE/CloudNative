CREATE TABLE LobSample(
	lob_id INTEGER,
	lobcolumn CLOB
);